__version__ = '0.1.0'

from main import save_numpickle, load_numpickle

